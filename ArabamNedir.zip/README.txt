database hazır olarak 1 tane Şirket, 
1 tane Yönetici
(Kullanıcı Adı:ÖrnekYönetici
Şifre:1234)
içeriyor.
Araba eklemek için 1 şirket,
Post Eklemek için ilk önce araba eklemek gereklidir.