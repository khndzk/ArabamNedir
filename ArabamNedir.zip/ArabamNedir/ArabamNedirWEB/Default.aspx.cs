﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VeriErisimKatmani;

namespace ArabamNedirWEB
{
    public partial class Default : System.Web.UI.Page
    {
        VeriModeli db = new VeriModeli();
        protected void Page_Load(object sender, EventArgs e)
        {
            rp_sirketler.DataSource = db.ArabaTumluSirketGetir();
            rp_sirketler.DataBind();
            short SirketID = Convert.ToInt16(Request.QueryString["SirketID"]);
            if (SirketID == 0)
            {
                rp_postlar.DataSource = db.GecerliPostlariSayfayaGetir();
                rp_postlar.DataBind();
            }
            else
            {
                if (ddl_arabalar.Items.Count == 0)
                {
                    ddl_arabalar.DataSource = db.SirketliTumArabalariGetir(SirketID);
                    ddl_arabalar.DataBind();
                }
                int ArabaID = Convert.ToInt32(ddl_arabalar.SelectedItem.Value);
                if (Convert.ToInt32(ddl_arabalar.SelectedItem.Value) == 0)
                {
                    rp_postlar.DataSource = db.GecerliPostlariSayfayaGetir(SirketID);
                }
                else
                {
                    rp_postlar.DataSource = db.GecerliPostlariSayfayaGetir(SirketID, ArabaID);
                }
                rp_postlar.DataBind();
            }
        }
        protected void ddl_arabalar_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void ibtn_foto_Click(object sender, ImageClickEventArgs e)
        {

        }
    }
}