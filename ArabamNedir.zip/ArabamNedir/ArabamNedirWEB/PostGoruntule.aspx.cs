﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services.Description;
using System.Web.UI;
using System.Web.UI.WebControls;
using VeriErisimKatmani;

namespace ArabamNedirWEB
{
    public partial class PostGoruntule : System.Web.UI.Page
    {
        VeriModeli db = new VeriModeli();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString.Count == 0)
            {
                Response.Redirect("Default.aspx");
            }
            Postlar post = db.PostGetir(Convert.ToInt32(Request.QueryString["PostID"]));
            lbl_baslik.Text = post.Baslik;
            lbl_posticerik.Text = post.Aciklama;
            lbl_Tarih.Text = Convert.ToString(post.YuklemeTarihi);
            lbl_UyeIsim.Text = post.YazarKAdi;
            img_kapakresim.ImageUrl = "../resimler/postresimleri/" + post.KapakFoto;

            #region Araba İşlemleri

            Araba araba = db.ArabayiPostaGetir(post.ArabaID);
            lbl_TurIsim.Text = "Araba Türü: " + Convert.ToString(araba.TipIsim);
            lbl_YakitIsim.Text = "Araba Yakıt Türü: " + Convert.ToString(araba.YakitIsim);
            lbl_SirketIsim.Text = Convert.ToString(araba.SirketIsim);
            lbl_Model.Text = Convert.ToString(araba.Model);

            lbl_CikisYili.Text = araba.CikisYili == -1 ? "" : "Çıkış Yılı: " + Convert.ToString(araba.CikisYili);
            lbl_MotorTipi.Text = "Motor: " + Convert.ToString(araba.MotorTipi);
            lbl_MaxGuc.Text = "Maks Güç: " + Convert.ToString(araba.MaxGuc);
            lbl_MaxTork.Text = "Maks Tork: " + Convert.ToString(araba.MaxTork);
            lbl_MaxRPM.Text = "Maks Devir: " + Convert.ToString(araba.MaxRPM);
            lbl_SifirdanYuze.Text = "0-100 km/h'ye hızlanma süresi: " + Convert.ToString(araba.SifirdenYuze);
            lbl_Agirlik.Text = "Araba Ağırlığı: " + Convert.ToString(araba.Agirlik);
            lbl_MotorBoyutu.Text = Convert.ToString(araba.MotorBoyutu * 1000);
            lbl_YakitKullanimi.Text = "Araba 100km/L Yakıt Kullanımı: " + Convert.ToString(araba.YakitKullanimi);
            lbl_ValfSayisi.Text = Convert.ToString(araba.ValfSayisi);
            lbl_EkzantrikIsim.Text = Convert.ToString(araba.EkzantrikIsim);
            lbl_EnjeksiyonIsim.Text = Convert.ToString(araba.EnjeksiyonIsim);
            lbl_SanzimanIsim.Text = Convert.ToString(araba.SanzimanTipi);
            lbl_VitesSayisi.Text = "Vites Sayısı: " + Convert.ToString(araba.VitesSayisi);
            lbl_CekisIsim.Text = "Çekiş: " + Convert.ToString(araba.CekisIsim);
            lbl_InduksiyonIsim.Text = Convert.ToString(araba.InduksiyonIsim);
            lbl_Diger.Text = Convert.ToString(araba.Diger);
            #endregion

            rp_yorumlar.DataSource = db.PostaYorumGetir(Convert.ToInt32(Request.QueryString["PostID"]));
            rp_yorumlar.DataBind();

            if (Session["uye"] == null)
            {
                pnl_girisvar.Visible = false;
                pnl_girisyok.Visible = true;
            }
            else
            {
                pnl_girisyok.Visible = false;
                pnl_girisvar.Visible = true;
            }
        }

        protected void lbtn_yorumgonder_Click(object sender, EventArgs e)
        {
            if (tb_yorum.Text != null)
            {
                Uyeler uye = (Uyeler)Session["uye"];
                Yorumlar yorum = new Yorumlar();
                yorum.Icerik = tb_yorum.Text;
                yorum.UyeID = uye.ID;
                yorum.PostID = Convert.ToInt32(Request.QueryString["PostID"]);
                yorum.Tarih = DateTime.Now;
                yorum.Durum = false;
                if (db.YorumEkle(yorum))
                {
                    pnl_basarili.Visible = true;
                    pnl_hatapanel.Visible = false;
                }
                else
                {
                    pnl_basarili.Visible = false;
                    pnl_hatapanel.Visible = true;
                    ltrl_hatamesaj.Text = "Yorum gönderirken bir hata oluştu lütfen daha sonra tekrar deneyin";
                }
            }
        }
    }
}