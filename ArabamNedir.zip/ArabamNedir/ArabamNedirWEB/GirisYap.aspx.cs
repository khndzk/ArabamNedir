﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VeriErisimKatmani;

namespace ArabamNedirWEB
{
    public partial class GirisYap : System.Web.UI.Page
    {
        VeriModeli db = new VeriModeli();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_giris_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tb_kadi.Text))
            {
                pnl_hata.Visible = true;
                lbl_hata.Text = "Kullanıcı Adı Boş Bırakılamaz";
            }
            else if (string.IsNullOrEmpty(tb_sifre.Text))
            {
                pnl_hata.Visible = true;
                lbl_hata.Text = "Şifre Boş Bırakılamaz";
            }
            else
            {
                Uyeler uye = db.UyeGiris(tb_kadi.Text, tb_sifre.Text);
                if (uye == null)
                {
                    pnl_hata.Visible = true;
                    lbl_hata.Text = "Kullanıcı bulunamadı Lütfen bilgilerinizi kontrol ediniz.";
                }
                else if (uye.ID == 0)
                {
                    pnl_hata.Visible = true;
                    lbl_hata.Text = "Kullanıcı bulunamadı Lütfen bilgilerinizi kontrol ediniz.";
                }
                else if (uye.Durum == false)
                {
                    pnl_hata.Visible = true;
                    lbl_hata.Text = "Hesabın girişi yasaklıdır.";
                }
                else
                {
                    Session["uye"] = uye;
                    Response.Redirect("Default.aspx");
                }
            }
        }
    }
}