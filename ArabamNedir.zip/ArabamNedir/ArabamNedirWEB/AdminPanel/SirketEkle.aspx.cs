﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VeriErisimKatmani;

namespace ArabamNedirWEB.AdminPanel
{
    public partial class SirketEkle : System.Web.UI.Page
    {
        VeriModeli db = new VeriModeli();
        protected void Page_Load(object sender, EventArgs e)
        {
            Yonetici yon = (Yonetici)Session["yonetici"];
            if (!(yon == null))
            {
                if (yon.TurID > 2)
                {
                    Response.Redirect("Empty.aspx");
                }
            }
        }
        protected void btn_Kaydet_Click(object sender, EventArgs e)
        {
            Sirketler s = new Sirketler();
            s.SirketAdi = tb_SirketAdi.Text;
            if (!string.IsNullOrEmpty(tb_SirketAdi.Text))
            {
                if (db.SirketEkle(s))
                {
                    pnl_hatapanel.Visible = false;
                    pnl_basarili.Visible = true;
                }
                else
                {
                    pnl_hatapanel.Visible = true;
                    pnl_basarili.Visible = false;
                    ltrl_hata.Text = "Şirket eklerken bir hata oluştu";
                }
            }
            else
            {
                pnl_hatapanel.Visible = true;
                pnl_basarili.Visible = false;
                ltrl_hata.Text = "Şirket ismi boş bırakılamaz";
            }

        }
    }
}