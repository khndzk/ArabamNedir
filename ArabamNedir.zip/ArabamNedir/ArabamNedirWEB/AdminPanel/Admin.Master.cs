﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VeriErisimKatmani;

namespace ArabamNedirWEB.AdminPanel
{
    public partial class Admin : System.Web.UI.MasterPage
    {
        VeriModeli db = new VeriModeli();
        protected void Page_Load(object sender, EventArgs e)
        {
            Yonetici y = (Yonetici)Session["yonetici"];
            if (y == null)
            {
                Response.Redirect("AdminGiris.aspx");
            }
            else
            {
                if (y.TurID == 3)
                {
                    lbtn_postekle.Visible = true;
                    lbtn_postlistele.Visible = true;
                }
                if (y.TurID < 3)
                {
                    lbtn_arabaekle.Visible = true;
                    lbtn_arabalistele.Visible = true;
                    lbtn_kullaniciarat.Visible = true;
                    lbtn_sirket.Visible = true;
                    lbtn_yoneticiarat.Visible = true;
                    lbtn_yonetim.Visible = true;
                }
                if (y.TurID < 2)
                {
                    lbtn_yoneticiekle.Visible = true;
                }

                lbl_kadi.Text = y.KullaniciAdi + "(" + db.YoneticiTurGetir(y.ID) + ")";
            }
        }

        protected void lbtn_cikis_Click(object sender, EventArgs e)
        {
            Session["yonetici"] = null;
            Response.Redirect("AdminGiris.aspx");
        }
    }
}