﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VeriErisimKatmani;

namespace ArabamNedirWEB.AdminPanel
{
    public partial class PostListele : System.Web.UI.Page
    {
        VeriModeli db = new VeriModeli();
        protected void Page_Load(object sender, EventArgs e)
        {
            Yonetici y = (Yonetici)Session["yonetici"];
            if (!(y == null))
            {
                if (y.TurID == 3)
                {
                    lv_postlar.DataSource = db.TumYazarliPostlariListeyeGetir(y.ID);
                }
                else
                {
                    lv_postlar.DataSource = db.TumPostlariListeyeGetir();
                }
                lv_postlar.DataBind();
            }
        }

        protected void lv_postlar_ItemCommand(object sender, ListViewCommandEventArgs e)
        {
            Yonetici y = (Yonetici)Session["yonetici"];
            int postID = Convert.ToInt32(e.CommandArgument);
            bool? b = db.YoneticiKarsilastir(postID, y.ID);
            
            if (y.TurID < 3)
            {
                b = true;
            }
            if (e.CommandName == "sil" && b == true)
            {
                int id = Convert.ToInt32(e.CommandArgument);
                db.PostSil(id);
                if (y.TurID == 3)
                {
                    lv_postlar.DataSource = db.TumYazarliPostlariListeyeGetir(y.ID);
                }
                else
                {
                    lv_postlar.DataSource = db.TumPostlariListeyeGetir();
                }
                lv_postlar.DataBind();
            }
            else if (e.CommandName == "durum" && b == true)
            {
                int id = Convert.ToInt32(e.CommandArgument);
                if (y.TurID == 3)
                {
                    db.PostGizle(id);
                    lv_postlar.DataSource = db.TumYazarliPostlariListeyeGetir(y.ID);
                }
                else
                {
                    db.PostDurumDegistir(id);
                    lv_postlar.DataSource = db.TumPostlariListeyeGetir();
                }
                lv_postlar.DataBind();
            }
        }
    }
}