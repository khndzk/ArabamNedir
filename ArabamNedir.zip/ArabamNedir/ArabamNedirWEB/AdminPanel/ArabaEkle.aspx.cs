﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VeriErisimKatmani;

namespace ArabamNedirWEB.AdminPanel
{
    public partial class ArabaEkle : System.Web.UI.Page
    {
        VeriModeli db = new VeriModeli();
        protected void Page_Load(object sender, EventArgs e)
        {
            Yonetici yon = (Yonetici)Session["yonetici"];
            if (!(yon == null))
            {
                if (yon.TurID > 2)
                {
                    Response.Redirect("Empty.aspx");
                }
            }

            if (!IsPostBack)
            {
                ddl_ArabaTip.DataSource = db.ArabaTipleriGetir();
                ddl_ArabaTip.DataBind();
                ddl_ArabaYakit.DataSource = db.ArabaYakitGetir();
                ddl_ArabaYakit.DataBind();
                ddl_ArabaSirket.DataSource = db.ArabaSirketGetir();
                ddl_ArabaSirket.DataBind();
                ddl_Cekis.DataSource = db.ArabaCekisGetir();
                ddl_Cekis.DataBind();
                ddl_Ekzantrik.DataSource = db.ArabaExaGetir();
                ddl_Ekzantrik.DataBind();
                ddl_Enjeksiyon.DataSource = db.ArabaEnjGetir();
                ddl_Enjeksiyon.DataBind();
                ddl_Induksiyon.DataSource = db.ArabaIndGetir();
                ddl_Induksiyon.DataBind();
                ddl_Sanziman.DataSource = db.ArabaSanzGetir();
                ddl_Sanziman.DataBind();
            }
        }

        protected void btn_Kaydet_Click(object sender, EventArgs e)
        {
            Araba araba = new Araba();
            bool b1 = string.IsNullOrEmpty(tb_Model.Text);
            bool b2 = string.IsNullOrEmpty(tb_MotorTipi.Text);
            bool b3 = string.IsNullOrEmpty(tb_motorboyut.Text);
            bool b4 = string.IsNullOrEmpty(tb_vitessayi.Text);
            bool b5 = string.IsNullOrEmpty(tb_Valf.Text);
            bool b6 = string.IsNullOrEmpty(tb_CikisYili.Text);

            araba.TipID = Convert.ToByte(ddl_ArabaTip.SelectedItem.Value);
            araba.YakitID = Convert.ToByte(ddl_ArabaYakit.SelectedItem.Value);
            araba.SirketID = Convert.ToInt16(ddl_ArabaSirket.SelectedItem.Value);
            araba.Model = tb_Model.Text;
            araba.CikisYili = db.NullIseEksiInt16(tb_CikisYili.Text);
            araba.MotorTipi = tb_MotorTipi.Text;
            araba.MaxGuc = db.NullIseEksiInt16(tb_MaxGuc.Text);
            araba.MaxTork = db.NullIseEksiInt16(tb_MaxTork.Text);
            araba.MaxRPM = db.NullIseEksiInt16(tb_MaxRPM.Text);
            araba.SifirdenYuze = db.NullIseEksiDouble(db.KarakterCevir(tb_sifirdanyuze.Text));
            araba.Agirlik = db.NullIseEksiInt16(tb_Agirlik.Text);
            araba.MotorBoyutu = db.NullIseEksiDouble(db.KarakterCevir(tb_motorboyut.Text));
            araba.YakitKullanimi = db.NullIseEksiDouble(db.KarakterCevir(tb_yakitkullanimi.Text));
            araba.EkzantrikID = Convert.ToByte(ddl_Ekzantrik.SelectedItem.Value);
            araba.EnjeksiyonID = Convert.ToByte(ddl_Enjeksiyon.SelectedItem.Value);
            araba.SanzimanID = Convert.ToByte(ddl_Sanziman.SelectedItem.Value);
            araba.CekisID = Convert.ToByte(ddl_Cekis.SelectedItem.Value); ;
            araba.InduksiyonID = Convert.ToByte(ddl_Induksiyon.SelectedItem.Value);
            araba.Diger = tb_diger.Text;
            if (!(b1 || b2 || b3 || b4 || b5 || b6))
            {
                araba.ValfSayisi = Convert.ToByte(tb_Valf.Text);
                araba.VitesSayisi = Convert.ToByte(tb_vitessayi.Text);
                if (db.ArabaEkle(araba))
                {
                    pnl_hatapanel.Visible = false;
                    pnl_basarili.Visible = true;
                }
                else
                {
                    pnl_hatapanel.Visible = true;
                    pnl_basarili.Visible = false;
                    ltrl_hata.Text = "Araba eklerken bir hata oluştu";
                }
            }
            else
            {
                pnl_hatapanel.Visible = true;
                pnl_basarili.Visible = false;
                ltrl_hata.Text = "Model,Çıkış Yılı,Motor Tipi, Motor Boyutu, Vites Sayısı ,Valf Sayısı boş bırakılamaz";
            }

        }
    }
}