﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VeriErisimKatmani;

namespace ArabamNedirWEB.AdminPanel
{
    public partial class SirketDuzenle : System.Web.UI.Page
    {
        VeriModeli db = new VeriModeli();
        protected void Page_Load(object sender, EventArgs e)
        {
            Yonetici yon = (Yonetici)Session["yonetici"];
            if (!(yon == null))
            {
                if (yon.TurID > 2)
                {
                    Response.Redirect("Empty.aspx");
                }
            }
            if (Request.QueryString.Count != 0)
            {
                if (!IsPostBack)
                {
                    int id = Convert.ToInt32(Request.QueryString["sirketID"]);
                    Sirketler s = db.ArabaSirketGetir(id);
                    tb_SirketAdi.Text = s.SirketAdi.ToString();
                }
            }
            else
            {
                Response.Redirect("ArabaListele.aspx");
            }
        }

        protected void btn_Kaydet_Click(object sender, EventArgs e)
        {
            Sirketler s = new Sirketler();
            s.ID = Convert.ToInt32(Request.QueryString["sirketID"]);
            s.SirketAdi = tb_SirketAdi.Text;
            if (!string.IsNullOrEmpty(tb_SirketAdi.Text))
            {
                if (db.SirketDuzenle(s))
                {
                    pnl_hatapanel.Visible = false;
                    pnl_basarili.Visible = true;
                }
                else
                {
                    pnl_hatapanel.Visible = true;
                    pnl_basarili.Visible = false;
                    ltrl_hata.Text = "Şirket düzenlerken bir hata oluştu";
                }
            }
            else
            {
                pnl_hatapanel.Visible = true;
                pnl_basarili.Visible = false;
                ltrl_hata.Text = "Şirket ismi boş bırakılamaz";
            }
        }
    }
}