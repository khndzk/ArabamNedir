﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VeriErisimKatmani;

namespace ArabamNedirWEB.AdminPanel
{
    public partial class ArabaListele : System.Web.UI.Page
    {
        VeriModeli db = new VeriModeli();
        protected void Page_Load(object sender, EventArgs e)
        {
            Yonetici yon = (Yonetici)Session["yonetici"];
            if (!(yon == null))
            {
                if (yon.TurID > 2)
                {
                    Response.Redirect("Empty.aspx");
                }
            }
            lv_arabalar.DataSource = db.TumArabalariListeyeGetir();
            lv_arabalar.DataBind();
        }

        protected void lv_arabalar_ItemCommand(object sender, ListViewCommandEventArgs e)
        {
            if (e.CommandName == "sil")
            {
                int id = Convert.ToInt32(e.CommandArgument);
                db.ArabaSil(id);
                lv_arabalar.DataSource = db.TumArabalariListeyeGetir();
                lv_arabalar.DataBind();
            }
        }
    }
}