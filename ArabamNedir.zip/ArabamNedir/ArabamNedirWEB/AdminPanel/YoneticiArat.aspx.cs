﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VeriErisimKatmani;

namespace ArabamNedirWEB.AdminPanel
{
    public partial class YoneticiArat : System.Web.UI.Page
    {
        VeriModeli db = new VeriModeli();
        protected void Page_Load(object sender, EventArgs e)
        {
            Yonetici yon = (Yonetici)Session["yonetici"];
            if (!(yon == null))
            {
                if (yon.TurID > 2)
                {
                    Response.Redirect("Empty.aspx");
                }
            }
            lv_yoneticiler.DataSource = db.YoneticiGetir(tb_isim.Text);
            lv_yoneticiler.DataBind();
        }

        protected void lv_yoneticiler_ItemCommand(object sender, ListViewCommandEventArgs e)
        {
            Yonetici y = (Yonetici)Session["yonetici"];
            if (e.CommandName == "durum")
            {
                if (y.TurID == 1)
                {
                    db.YoneticiDurumDegistir(Convert.ToInt32(e.CommandArgument));
                    lv_yoneticiler.DataSource = db.YoneticiGetir(tb_isim.Text);
                    lv_yoneticiler.DataBind();
                }
            }
        }

        protected void lbtn_arat_Click(object sender, EventArgs e)
        {
            lv_yoneticiler.DataSource = db.YoneticiGetir(tb_isim.Text);
            lv_yoneticiler.DataBind();
        }
    }
}