﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VeriErisimKatmani;

namespace ArabamNedirWEB.AdminPanel
{
    public partial class KullaniciArat : System.Web.UI.Page
    {
        VeriModeli db = new VeriModeli();
        protected void Page_Load(object sender, EventArgs e)
        {
            Yonetici yon = (Yonetici)Session["yonetici"];
            if (!(yon == null))
            {
                if (yon.TurID > 2)
                {
                    Response.Redirect("Empty.aspx");
                }
            }
            lv_uyeler.DataSource = db.UyeGetir(tb_isim.Text);
            lv_uyeler.DataBind();
        }

        protected void lv_uyeler_ItemCommand(object sender, ListViewCommandEventArgs e)
        {
            if (e.CommandName == "durum")
            {
                db.UyeDurumDegistir(Convert.ToInt32(e.CommandArgument));
                lv_uyeler.DataSource = db.UyeGetir(tb_isim.Text);
                lv_uyeler.DataBind();
            }
            if (e.CommandName == "sil")
            {
                db.UyeSil(Convert.ToInt32(e.CommandArgument));
                lv_uyeler.DataSource = db.UyeGetir(tb_isim.Text);
                lv_uyeler.DataBind();
            }
        }
        protected void lbtn_arat_Click(object sender, EventArgs e)
        {
            lv_uyeler.DataSource = db.UyeGetir(tb_isim.Text);
            lv_uyeler.DataBind();
        }
    }
}