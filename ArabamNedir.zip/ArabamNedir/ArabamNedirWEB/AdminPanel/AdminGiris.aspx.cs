﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VeriErisimKatmani;

namespace ArabamNedirWEB.AdminPanel
{
    public partial class AdminGiris : System.Web.UI.Page
    {
        VeriModeli db = new VeriModeli();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_giris_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tb_kadi.Text))
            {
                pnl_hata.Visible = true;
                lbl_hata.Text = "Kullanıcı Adı Boş Bırakılamaz";
            }
            else if (string.IsNullOrEmpty(tb_sifre.Text))
            {
                pnl_hata.Visible = true;
                lbl_hata.Text = "Şifre Boş Bırakılamaz";
            }
            else
            {
                Yonetici yon = db.YoneticiGiris(tb_kadi.Text, tb_sifre.Text);
                if (yon == null)
                {
                    pnl_hata.Visible = true;
                    lbl_hata.Text = "Kullanıcı bulunamadı null Lütfen bilgilerinizi kontrol ediniz.";
                }
                else if (yon.ID == 0)
                {
                    pnl_hata.Visible = true;
                    lbl_hata.Text = "Kullanıcı bulunamadı Lütfen bilgilerinizi kontrol ediniz.";
                }
                else if (yon.Durum == false)
                {
                    pnl_hata.Visible = true;
                    lbl_hata.Text = "Hesabın girişi yasaklıdır.Lütfen yönetici ile görüşün";
                }
                else
                {
                    Session["yonetici"] = yon;
                    Response.Redirect("Default.aspx");
                }
            }
        }
    }
}