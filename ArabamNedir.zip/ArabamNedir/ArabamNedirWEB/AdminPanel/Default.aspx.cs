﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VeriErisimKatmani;

namespace ArabamNedirWEB.AdminPanel
{
    public partial class Default : System.Web.UI.Page
    {
        VeriModeli db = new VeriModeli();
        protected void Page_Load(object sender, EventArgs e)
        {
            Yonetici yon = (Yonetici)Session["yonetici"];
            if (!(yon == null))
            {
                if (yon.TurID > 2)
                {
                    Response.Redirect("Empty.aspx");
                }
            }
            lv_yorumlar.DataSource = db.OnaylanmamisYorumlariGetir();
            lv_yorumlar.DataBind();
            lbl_kullanicisayi.Text = "Toplam Kullanıcı Sayısı: " + Convert.ToString(db.ToplamKullaniciSayisi());
            lbl_postsayi.Text = "Toplam Post Sayısı: " + Convert.ToString(db.ToplamPostSayisi());
            lbl_yoneticisayi.Text = "Toplam Yönetici Sayısı: " + Convert.ToString(db.ToplamYoneticiSayisi());
            lbl_yorumsayi.Text = "Toplam Yorum Sayısı: " + Convert.ToString(db.ToplamYorumSayisi());
        }

        protected void lv_yorumlar_ItemCommand(object sender, ListViewCommandEventArgs e)
        {
            if (e.CommandName == "sil")
            {
                int id = Convert.ToInt32(e.CommandArgument);
                db.YorumSil(id);
                lv_yorumlar.DataSource = db.OnaylanmamisYorumlariGetir();
                lv_yorumlar.DataBind();
            }
            else if (e.CommandName == "durum")
            {
                int id = Convert.ToInt32(e.CommandArgument);
                db.YorumDurumDegistir(id);
                lv_yorumlar.DataSource = db.OnaylanmamisYorumlariGetir();
                lv_yorumlar.DataBind();
            }
        }
    }
}