﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VeriErisimKatmani;
using static System.Net.Mime.MediaTypeNames;

namespace ArabamNedirWEB.AdminPanel
{
    public partial class HesapDuzenle : System.Web.UI.Page
    {
        VeriModeli db = new VeriModeli();
        protected void Page_Load(object sender, EventArgs e)
        {
            Yonetici yon = (Yonetici)Session["yonetici"];
            if (!(yon == null))
            {
                if (yon.TurID > 1)
                {
                    Response.Redirect("Default.aspx");
                }
                if (!IsPostBack)
                {
                    tb_Email.Text = yon.Email;
                    tb_isim.Text = yon.Isim;
                    tb_KAdi.Text = yon.KullaniciAdi;
                    tb_sifre.Text = yon.Sifre;
                    tb_soyisim.Text = yon.Soyisim;
                }
            }
        }

        protected void btn_Kaydet_Click(object sender, EventArgs e)
        {
            Yonetici yon = new Yonetici();
            bool b1 = string.IsNullOrEmpty(tb_KAdi.Text);
            bool b2 = string.IsNullOrEmpty(tb_Email.Text);
            bool b3 = string.IsNullOrEmpty(tb_sifre.Text);
            Yonetici eskiyon = (Yonetici)Session["yonetici"];
            yon.ID = eskiyon.ID;
            yon.Isim = tb_isim.Text;
            yon.Soyisim = tb_soyisim.Text;
            yon.KullaniciAdi = tb_KAdi.Text;
            yon.Email = tb_Email.Text;
            yon.Sifre = tb_sifre.Text;
            if (!(b1 || b2 || b3))
            {
                bool? b = db.YoneticiKAdiMusaitMi(tb_KAdi.Text);
                if (b == true)
                {
                    if (db.YoneticiHesapDuzenle(yon))
                    {
                        pnl_hatapanel.Visible = false;
                        pnl_basarili.Visible = true;
                        Session["Yonetici"] = null;
                        Response.Redirect("AdminGiris.aspx");
                    }
                    else
                    {
                        pnl_hatapanel.Visible = true;
                        pnl_basarili.Visible = false;
                        ltrl_hata.Text = "Yönetici eklerken bir hata oluştu";
                    }
                }
                else if (b == false)
                {
                    pnl_hatapanel.Visible = true;
                    pnl_basarili.Visible = false;
                    ltrl_hata.Text = "Kullanıcı adı çoktan alınmış";
                }
                else
                {
                    pnl_hatapanel.Visible = true;
                    pnl_basarili.Visible = false;
                    ltrl_hata.Text = "Sunucuda beklenmedik bir hata oluştu Lütfen sorunu çözdükten sonra tekrar deneyin";
                }
            }
            else
            {
                pnl_hatapanel.Visible = true;
                pnl_basarili.Visible = false;
                ltrl_hata.Text = "Kullanıcı Adı, E-mail,Şifre boş bırakılamaz";
            }

        }
    }
}