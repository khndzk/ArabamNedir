﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VeriErisimKatmani;

namespace ArabamNedirWEB.AdminPanel
{
    public partial class PostEkle : System.Web.UI.Page
    {
        VeriModeli db = new VeriModeli();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ddl_Araba.DataSource = db.TumArabaIsimGetir();
                ddl_Araba.DataBind();
            }
        }

        protected void btn_Kaydet_Click(object sender, EventArgs e)
        {
            Postlar post = new Postlar();
            bool b1 = string.IsNullOrEmpty(tb_Baslik.Text);
            bool b2 = string.IsNullOrEmpty(tb_aciklama.Text);
            Yonetici y = (Yonetici)Session["yonetici"];
            post.YazarID = y.ID;
            post.ArabaID = Convert.ToInt32(ddl_Araba.SelectedItem.Value);
            post.Aciklama = tb_aciklama.Text;
            post.Baslik = tb_Baslik.Text;
            post.AlinanYil = db.NullIseEksiInt16(tb_yil.Text);
            post.AlinanFiyat = db.NullIseEksiInt32(tb_fiyat.Text);
            post.ElDurumu = cb_el.Checked;
            post.YuklemeTarihi = DateTime.Now;
            post.GizliMi = !cb_gizli.Checked;
            post.Durum = true;
            bool eklemedurum = true;
            if (!(b1 || b2))
            {
                if (fu_kapakresim.HasFile)
                {
                    FileInfo fi = new FileInfo(fu_kapakresim.FileName);
                    string uzanti = fi.Extension;
                    if (uzanti == ".jpg" || uzanti == ".png")
                    {
                        string isim = Guid.NewGuid().ToString();
                        post.KapakFoto = isim + uzanti;
                        fu_kapakresim.SaveAs(Server.MapPath("../resimler/postresimleri/" + isim + uzanti));
                    }
                    else
                    {
                        eklemedurum = false;
                        pnl_basarili.Visible = false;
                        pnl_hatapanel.Visible = true;
                        
                        ltrl_hata.Text = "Resim formatı uygun değil. sadece .jpg veya .png dosya kabul edilir";
                    }
                }
                else
                {
                    post.KapakFoto = "none.png";
                }
                if (eklemedurum)
                {
                    if (db.PostEkle(post))
                    {
                        pnl_basarili.Visible = true;
                        pnl_hatapanel.Visible = false;
                    }
                    else
                    {
                        pnl_basarili.Visible = false;
                        pnl_hatapanel.Visible = true;
                        ltrl_hata.Text = "Post eklenirken bir hata oluştu";
                    }
                }
            }
            else
            {
                pnl_hatapanel.Visible = true;
                pnl_basarili.Visible = false;
                ltrl_hata.Text = "Başlık ve Açıklama boş bırakılamaz";
            }
        }
    }
}