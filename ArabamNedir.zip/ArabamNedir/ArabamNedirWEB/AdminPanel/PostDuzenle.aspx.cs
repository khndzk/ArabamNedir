﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VeriErisimKatmani;

namespace ArabamNedirWEB.AdminPanel
{
    public partial class PostDuzenle : System.Web.UI.Page
    {
        VeriModeli db = new VeriModeli();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString.Count != 0)
            {
                Yonetici y = (Yonetici)Session["yonetici"];
                int postID = Convert.ToInt32(Request.QueryString["postID"]);
                bool? b = db.YoneticiKarsilastir(postID, y.ID);
                if (b == null || b == false)
                {
                    Response.Redirect("PostListele.aspx");
                }
                else
                {
                    if (!IsPostBack)
                    {
                        Postlar post = db.PostGetir(postID);
                        ddl_Araba.DataSource = db.TumArabaIsimGetir();
                        ddl_Araba.DataBind();
                        ddl_Araba.SelectedValue = post.ArabaID.ToString();
                        //
                        tb_aciklama.Text = post.Aciklama.ToString();
                        tb_Baslik.Text = post.Baslik.ToString();
                        string fiyat = post.AlinanFiyat == -1 ? "" : post.AlinanFiyat.ToString();
                        tb_fiyat.Text = fiyat;
                        string yil = post.AlinanYil == -1 ? "" : post.AlinanYil.ToString();
                        tb_yil.Text = yil;
                        cb_el.Checked = post.ElDurumu;
                        cb_gizli.Checked = !post.GizliMi;
                        img_kapakresim.ImageUrl = "../resimler/postresimleri/" + post.KapakFoto;
                    }
                }
            }
            else
            {
                Response.Redirect("PostListele.aspx");
            }
        }
        protected void btn_Kaydet_Click(object sender, EventArgs e)
        {
            Postlar post = new Postlar();
            bool b1 = string.IsNullOrEmpty(tb_Baslik.Text);
            bool b2 = string.IsNullOrEmpty(tb_aciklama.Text);
            post.ID = Convert.ToInt32(Request.QueryString["postID"]);
            post.ArabaID = Convert.ToInt32(ddl_Araba.SelectedItem.Value);
            post.Aciklama = tb_aciklama.Text;
            post.Baslik = tb_Baslik.Text;
            post.AlinanYil = db.NullIseEksiInt16(tb_yil.Text);
            post.AlinanFiyat = db.NullIseEksiInt32(tb_fiyat.Text);
            post.ElDurumu = cb_el.Checked;
            post.YuklemeTarihi = DateTime.Now;
            post.GizliMi = !cb_gizli.Checked;
            bool eklemedurum = true;
            if (!(b1 || b2))
            {
                if (fu_kapakresim.HasFile)
                {
                    FileInfo fi = new FileInfo(fu_kapakresim.FileName);
                    string uzanti = fi.Extension;
                    if (uzanti == ".jpg" || uzanti == ".png")
                    {
                        string isim = Guid.NewGuid().ToString();
                        post.KapakFoto = isim + uzanti;
                        fu_kapakresim.SaveAs(Server.MapPath("../resimler/postresimleri/" + isim + uzanti));
                    }
                    else
                    {
                        eklemedurum = false;
                        pnl_basarili.Visible = false;
                        pnl_hatapanel.Visible = true;
                        ltrl_hata.Text = "Resim Formatı uygun değildir. jpg ve png dosya kabul edilir";
                    }
                }
                else
                {
                    Postlar eskipost = db.PostGetir(Convert.ToInt32(Request.QueryString["postID"]));
                    if (eskipost.KapakFoto == "none.png")
                    {
                        post.KapakFoto = "none.png";
                    }
                    else
                    {
                        post.KapakFoto = eskipost.KapakFoto;
                    }
                }
                if (eklemedurum)
                {
                    if (db.PostDuzenle(post))
                    {
                        pnl_basarili.Visible = true;
                        pnl_hatapanel.Visible = false;
                    }
                    else
                    {
                        pnl_basarili.Visible = false;
                        pnl_hatapanel.Visible = true;
                        ltrl_hata.Text = "Post eklenirken bir hata oluştu";
                    }
                }
            }
            else
            {
                pnl_hatapanel.Visible = true;
                pnl_basarili.Visible = false;
                ltrl_hata.Text = "Başlık ve Açıklama boş bırakılamaz";
            }
        }
    }
}