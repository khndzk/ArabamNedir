﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VeriErisimKatmani;

namespace ArabamNedirWEB
{
    public partial class AnaMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Uyeler u = (Uyeler)Session["uye"];
            if (u == null)
            {
                lbtn_cikis.Visible = false;
                lbtn_girisyap.Visible = true;
                lbtn_hesapac.Visible = true;
                lbl_kadi.Text = "";
            }
            else
            {
                lbtn_cikis.Visible = true;
                lbtn_girisyap.Visible = false;
                lbtn_hesapac.Visible = false;
                lbl_kadi.Text = u.KullaniciAdi;
            }
        }
        protected void lbtn_hesapac_Click(object sender, EventArgs e)
        {
            Response.Redirect("HesapAc.aspx");
        }
        protected void lbtn_girisyap_Click(object sender, EventArgs e)
        {
            Response.Redirect("GirisYap.aspx");
        }

        protected void lbtn_cikis_Click(object sender, EventArgs e)
        {
            Session["uye"] = null;
            Response.Redirect("Default.aspx");
        }
    }
}