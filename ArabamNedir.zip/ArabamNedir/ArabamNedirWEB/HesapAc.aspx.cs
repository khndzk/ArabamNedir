﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VeriErisimKatmani;

namespace ArabamNedirWEB
{
    public partial class HesapAc : System.Web.UI.Page
    {
        VeriModeli db = new VeriModeli();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_giris_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tb_kadi.Text))
            {
                pnl_hata.Visible = true;
                lbl_hata.Text = "Kullanıcı Adı Boş Bırakılamaz";
            }
            else if (string.IsNullOrEmpty(tb_sifre.Text))
            {
                pnl_hata.Visible = true;
                lbl_hata.Text = "Şifre Boş Bırakılamaz";
            }
            else if (string.IsNullOrEmpty(tb_email.Text))
            {
                pnl_hata.Visible = true;
                lbl_hata.Text = "Email Boş Bırakılamaz";
            }
            else
            {
                Uyeler u = new Uyeler();
                if (tb_kadi.Text.Length >= 4)
                {
                    u.KullaniciAdi = tb_kadi.Text;
                    u.Sifre = tb_sifre.Text;
                    u.Email = tb_email.Text;
                    u.Durum = true;
                    u.UyelikTarihi = DateTime.Now;
                    bool? b = db.UyeKAdiMusaitMi(u.KullaniciAdi);
                    if (b == true)
                    {
                        if (db.EmailMi(u.Email))
                        {
                            if (db.UyeHesapAc(u))
                            {
                                Uyeler uye = db.UyeGiris(u.KullaniciAdi, u.Sifre);
                                if (uye == null)
                                {
                                    pnl_hata.Visible = true;
                                    lbl_hata.Text = "Hesaba girerken bir hata oluştu.Daha sonra tekrar deneyin.(açtığınız hesap kalacaktır)";
                                }
                                else if (uye.ID == 0)
                                {
                                    pnl_hata.Visible = true;
                                    lbl_hata.Text = "Hesaba girerken bir hata oluştu.Daha sonra tekrar deneyin.(açtığınız hesap kalacaktır)";
                                }
                                else if (uye.Durum == false)
                                {
                                    pnl_hata.Visible = true;
                                    lbl_hata.Text = "Hesaba girerken bir hata oluştu.Daha sonra tekrar deneyin.(açtığınız hesap kalacaktır)";
                                }
                                else
                                {
                                    Session["uye"] = uye;
                                    Response.Redirect("Default.aspx");
                                }
                            }
                            else
                            {
                                pnl_hata.Visible = true;
                                lbl_hata.Text = "Hesap açarken bir hata oluştu.Lütfen daha sonra tekrar deneyin.";
                            }
                        }
                        else
                        {
                            pnl_hata.Visible = true;
                            lbl_hata.Text = "Geçerli bir Email girmediniz lütfen tekrar deneyin.";
                        }

                    }
                    else if (b == false)
                    {
                        pnl_hata.Visible = true;
                        lbl_hata.Text = "Kullanıcı adı çoktan alınmış! Başka bir Kullanıcı Adı girin.";
                    }
                    else
                    {
                        pnl_hata.Visible = true;
                        lbl_hata.Text = "Beklenmedik bir hata oluştu lütfen daha sonra tekrar deneyin.";
                    }
                }
                else
                {
                    pnl_hata.Visible = true;
                    lbl_hata.Text = "Kullanıcı adı uzunluğu en az 4 karakter olmalıdır.";
                }
            }
        }
    }
}