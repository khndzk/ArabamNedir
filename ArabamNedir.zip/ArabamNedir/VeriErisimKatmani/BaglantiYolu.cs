﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VeriErisimKatmani
{
    internal class BaglantiYolu
    {
        public static string AnaBaglantiYolu = @"Data Source=DESKTOP-4TVIC86\SQLEXPRESS; Initial Catalog=ArabamNedirDB;Integrated Security=True";
    }
}
