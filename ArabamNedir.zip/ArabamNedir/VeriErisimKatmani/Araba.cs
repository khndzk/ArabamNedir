﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VeriErisimKatmani
{
    public class Araba
    {
        public int ID { get; set; }
        public byte TipID { get; set; }
        public string TipIsim { get; set; }
        public short SirketID { get; set; }
        public string SirketIsim { get; set; }
        public byte YakitID { get; set; }
        public string YakitIsim { get; set; }
        public string Model { get; set; }
        public short CikisYili { get; set; }
        public string MotorTipi { get; set; }
        public short MaxGuc { get; set; }
        public short MaxTork { get; set; }
        public short MaxRPM { get; set; }
        public double SifirdenYuze { get; set; }
        public short Agirlik { get; set; }
        public double MotorBoyutu { get; set; }
        public double YakitKullanimi { get; set; }
        public byte ValfSayisi { get; set; }
        public byte EkzantrikID { get; set; }
        public string EkzantrikIsim { get; set; }
        public byte EnjeksiyonID { get; set; }
        public string EnjeksiyonIsim { get; set; }
        public byte SanzimanID { get; set; }
        public string SanzimanTipi { get; set; }
        public byte VitesSayisi { get; set; }
        public byte CekisID { get; set; }
        public string CekisIsim { get; set; }
        public byte InduksiyonID { get; set; }
        public string InduksiyonIsim { get; set; }
        public string Diger { get; set; }
    }
}
