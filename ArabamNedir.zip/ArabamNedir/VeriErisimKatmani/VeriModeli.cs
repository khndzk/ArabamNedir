﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace VeriErisimKatmani
{
    // databasede eklenmesi gereken şeyleri ekle
    // araba ekle
    // bmw e60 520i olcak
    public class VeriModeli
    {
        SqlCommand komut;
        SqlConnection baglanti;
        StrIslemleri Islem = new StrIslemleri();
        public VeriModeli()
        {
            baglanti = new SqlConnection(BaglantiYolu.AnaBaglantiYolu);
            komut = baglanti.CreateCommand();

        }

        #region Araba Metotları

        public Araba ArabaGetir(int id)
        {
            Araba araba = new Araba();
            try
            {
                komut.CommandText = "SELECT * FROM Arabalar WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", id);
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    araba.ID = reader.GetInt32(0);
                    araba.TipID = reader.GetByte(1);
                    araba.YakitID = reader.GetByte(2);
                    araba.SirketID = reader.GetInt16(3);
                    araba.Model = reader.GetString(4);
                    araba.CikisYili = reader.GetInt16(5);
                    araba.MotorTipi = reader.GetString(6);
                    araba.MaxGuc = reader.GetInt16(7);
                    araba.MaxTork = reader.GetInt16(8);
                    araba.MaxRPM = reader.GetInt16(9);
                    araba.SifirdenYuze = Convert.ToDouble(reader.GetDecimal(10));
                    araba.Agirlik = reader.GetInt16(11);
                    araba.MotorBoyutu = Convert.ToDouble(reader.GetDecimal(12));
                    araba.YakitKullanimi = Convert.ToDouble(reader.GetDecimal(13));
                    araba.ValfSayisi = reader.GetByte(14);
                    araba.EkzantrikID = reader.GetByte(15);
                    araba.EnjeksiyonID = reader.GetByte(16);
                    araba.SanzimanID = reader.GetByte(17);
                    araba.VitesSayisi = reader.GetByte(18);
                    araba.CekisID = reader.GetByte(19);
                    araba.InduksiyonID = reader.GetByte(20);
                    araba.Diger = reader.GetString(21);
                }
                return araba;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public Araba ArabayiPostaGetir(int id)
        {
            Araba araba = new Araba();
            try
            {
                komut.CommandText = "SELECT A.ID,T.Tip,Y.Yakit,S.SirketAdi,A.Model,A.CikisYili,A.MotorTipi,A.MaxGuc,A.MaxTork,A.MaxRPM,A.SifirdanYuze,A.Agirlik,A.MotorBoyutu,A.YakitKullanimi,A.ValfSayisi,Exa.tip,Enj.tip,Sanz.tip,A.VitesSayisi,C.tip,Ind.tip,A.Diger FROM Arabalar AS A JOIN ArabaCekis AS C ON C.ID = A.CekisID JOIN ArabaTip AS T ON T.ID = A.TipID JOIN ArabaYakit AS Y ON Y.ID = A.YakitID JOIN Sirketler AS S ON S.ID = A.SirketID JOIN ArabaEkzantrik AS Exa ON Exa.ID = A.EkzantrikID JOIN ArabaEnjeksiyon AS Enj ON Enj.ID = A.EnjeksiyonID JOIN ArabaSanziman AS Sanz ON Sanz.ID = A.SanzimanID  JOIN ArabaInduksiyon AS Ind ON Ind.ID = A.InduksiyonID WHERE A.ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", id);
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    araba.ID = reader.GetInt32(0);
                    araba.TipIsim = reader.GetString(1);
                    araba.YakitIsim = reader.GetString(2);
                    araba.SirketIsim = reader.GetString(3);
                    araba.Model = reader.GetString(4);
                    araba.CikisYili = reader.GetInt16(5);
                    araba.MotorTipi = reader.GetString(6);
                    araba.MaxGuc = reader.GetInt16(7);
                    araba.MaxTork = reader.GetInt16(8);
                    araba.MaxRPM = reader.GetInt16(9);
                    araba.SifirdenYuze = Convert.ToDouble(reader.GetDecimal(10));
                    araba.Agirlik = reader.GetInt16(11);
                    araba.MotorBoyutu = Convert.ToDouble(reader.GetDecimal(12));
                    araba.YakitKullanimi = Convert.ToDouble(reader.GetDecimal(13));
                    araba.ValfSayisi = reader.GetByte(14);
                    araba.EkzantrikIsim = reader.GetString(15);
                    araba.EnjeksiyonIsim = reader.GetString(16);
                    araba.SanzimanTipi = reader.GetString(17);
                    araba.VitesSayisi = reader.GetByte(18);
                    araba.CekisIsim = reader.GetString(19);
                    araba.InduksiyonIsim = reader.GetString(20);
                    araba.Diger = reader.GetString(21);
                }
                return araba;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }
        public List<Araba> SirketliTumArabalariGetir(short SirketID)
        {
            try
            {
                List<Araba> arabalar = new List<Araba>();
                komut.CommandText = "SELECT A.ID,S.SirketAdi,A.Model FROM Arabalar AS A JOIN Sirketler AS S ON S.ID = A.SirketID WHERE SirketID=@sid";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@sid", SirketID);
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                Araba a = new Araba();
                a.ID = 0;
                a.Model = "Tümü";
                arabalar.Add(a);
                while (reader.Read())
                {
                    Araba araba = new Araba();
                    araba.ID = reader.GetInt32(0);
                    araba.SirketIsim = reader.GetString(1);
                    araba.Model = araba.SirketIsim + " " + reader.GetString(2);
                    arabalar.Add(araba);
                }
                return arabalar;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }
        public List<Araba> TumArabalariListeyeGetir()
        {
            List<Araba> arabalar = new List<Araba>();
            try
            {
                komut.CommandText = "SELECT A.ID,T.Tip,Y.Yakit,S.SirketAdi,Sanz.tip,A.Model,A.CikisYili,A.MotorTipi FROM Arabalar AS A JOIN ArabaTip AS T ON T.ID = A.TipID JOIN ArabaYakit AS Y ON Y.ID = A.YakitID JOIN Sirketler AS S ON S.ID = A.SirketID JOIN ArabaSanziman AS Sanz ON Sanz.ID = A.SanzimanID";
                komut.Parameters.Clear();
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    Araba araba = new Araba();
                    araba.ID = reader.GetInt32(0);
                    araba.TipIsim = reader.GetString(1);
                    araba.YakitIsim = reader.GetString(2);
                    araba.SirketIsim = reader.GetString(3);
                    araba.SanzimanTipi = reader.GetString(4);
                    araba.Model = reader.GetString(5);
                    araba.CikisYili = reader.GetInt16(6);
                    araba.MotorTipi = reader.GetString(7);
                    arabalar.Add(araba);
                }
                return arabalar;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }
        public List<Araba> TumArabaIsimGetir()
        {
            List<Araba> arabalar = new List<Araba>();
            try
            {
                komut.CommandText = "SELECT a.ID, s.SirketAdi, a.Model FROM Arabalar as a JOIN Sirketler AS s ON s.ID = a.SirketID";
                komut.Parameters.Clear();
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    Araba araba = new Araba();
                    araba.ID = reader.GetInt32(0);
                    araba.Model = reader.GetString(1) + " " + reader.GetString(2);
                    arabalar.Add(araba);
                }
                return arabalar;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public List<Sirketler> ArabaSirketGetir()
        {
            try
            {
                List<Sirketler> sirketler = new List<Sirketler>();
                komut.CommandText = "SELECT ID, SirketAdi FROM Sirketler";
                komut.Parameters.Clear();
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    Sirketler sirket = new Sirketler();
                    sirket.ID = reader.GetInt16(0);
                    sirket.SirketAdi = reader.GetString(1);
                    sirketler.Add(sirket);
                }
                return sirketler;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public List<Sirketler> ArabaTumluSirketGetir()
        {
            try
            {
                List<Sirketler> sirketler = new List<Sirketler>();
                komut.CommandText = "SELECT ID, SirketAdi FROM Sirketler";
                komut.Parameters.Clear();
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                Sirketler s = new Sirketler();
                s.ID = 0;
                s.SirketAdi = "Tümü";
                sirketler.Add(s);
                while (reader.Read())
                {
                    Sirketler sirket = new Sirketler();
                    sirket.ID = reader.GetInt16(0);
                    sirket.SirketAdi = reader.GetString(1);
                    sirketler.Add(sirket);
                }
                return sirketler;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public Sirketler ArabaSirketGetir(int id)
        {
            try
            {
                Sirketler sirket = new Sirketler();
                komut.CommandText = "SELECT ID, SirketAdi FROM Sirketler WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", id);
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    sirket.ID = reader.GetInt16(0);
                    sirket.SirketAdi = reader.GetString(1);
                }
                return sirket;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public bool SirketEkle(Sirketler s)
        {
            try
            {
                komut.CommandText = "INSERT INTO Sirketler(SirketAdi) VALUES(@isim)";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@isim", s.SirketAdi);
                baglanti.Open();
                komut.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public bool SirketDuzenle(Sirketler s)
        {
            try
            {
                komut.CommandText = "UPDATE Sirketler SET SirketAdi=@isim WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", s.ID);
                komut.Parameters.AddWithValue("@isim", s.SirketAdi);
                baglanti.Open();
                komut.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public void SirketSil(int id)
        {
            try
            {
                komut.CommandText = "DELETE FROM Sirketler WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", id);
                baglanti.Open();
                komut.ExecuteNonQuery();
            }
            finally
            {
                baglanti.Close();
            }
        }

        public bool ArabaEkle(Araba araba)
        {
            try
            {
                komut.CommandText = "INSERT INTO Arabalar(TipID,YakitID,SirketID,Model,CikisYili,MotorTipi,MaxGuc,MaxTork,MaxRPM,SifirdanYuze,Agirlik,MotorBoyutu,YakitKullanimi,ValfSayisi,EkzantrikID,EnjeksiyonID,SanzimanID,VitesSayisi,CekisID,InduksiyonID,Diger) VALUES(@tid,@yid,@sid,@m,@cy,@mtipi,@mguc,@mtork,@mrpm,@yuze,@agirlik,@mboyut,@yakitk,@valfs,@exaid,@enjid,@sanzid,@vsayi,@cid,@indid,@d)";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@tid", araba.TipID);
                komut.Parameters.AddWithValue("@yid", araba.YakitID);
                komut.Parameters.AddWithValue("@sid", araba.SirketID);
                komut.Parameters.AddWithValue("@m", araba.Model);
                komut.Parameters.AddWithValue("@cy", araba.CikisYili);
                komut.Parameters.AddWithValue("@mtipi", araba.MotorTipi);
                komut.Parameters.AddWithValue("@mguc", araba.MaxGuc);
                komut.Parameters.AddWithValue("@mtork", araba.MaxTork);
                komut.Parameters.AddWithValue("@mrpm", araba.MaxRPM);
                komut.Parameters.AddWithValue("@yuze", araba.SifirdenYuze);
                komut.Parameters.AddWithValue("@agirlik", araba.Agirlik);
                komut.Parameters.AddWithValue("@mboyut", araba.MotorBoyutu);
                komut.Parameters.AddWithValue("@yakitk", araba.YakitKullanimi);
                komut.Parameters.AddWithValue("@valfs", araba.ValfSayisi);
                komut.Parameters.AddWithValue("@exaid", araba.EkzantrikID);
                komut.Parameters.AddWithValue("@enjid", araba.EnjeksiyonID);
                komut.Parameters.AddWithValue("@sanzid", araba.SanzimanID);
                komut.Parameters.AddWithValue("@vsayi", araba.VitesSayisi);
                komut.Parameters.AddWithValue("@cid", araba.CekisID);
                komut.Parameters.AddWithValue("@indid", araba.InduksiyonID);
                komut.Parameters.AddWithValue("@d", araba.Diger);
                baglanti.Open();
                komut.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public void ArabaSil(int id)
        {
            try
            {
                komut.CommandText = "DELETE FROM Arabalar WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", id);
                baglanti.Open();
                komut.ExecuteNonQuery();
            }
            finally
            {
                baglanti.Close();
            }
        }

        public bool ArabaDuzenle(Araba araba)
        {
            try
            {
                komut.CommandText = "UPDATE Arabalar SET TipID=@tid,YakitID=@yid,SirketID=@sid,Model=@m,CikisYili=@cy,MotorTipi=@mtipi,MaxGuc=@mguc,MaxTork=@mtork,MaxRPM=@mrpm,SifirdanYuze=@yuze,Agirlik=@agirlik,MotorBoyutu=@mboyut,YakitKullanimi=@yakitk,ValfSayisi=@valfs,EkzantrikID=@exaid,EnjeksiyonID=@enjid,SanzimanID=@sanzid,VitesSayisi=@vsayi,CekisID=@cid,InduksiyonID=@indid,Diger=@d WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", araba.ID);
                komut.Parameters.AddWithValue("@tid", araba.TipID);
                komut.Parameters.AddWithValue("@yid", araba.YakitID);
                komut.Parameters.AddWithValue("@sid", araba.SirketID);
                komut.Parameters.AddWithValue("@m", araba.Model);
                komut.Parameters.AddWithValue("@cy", araba.CikisYili);
                komut.Parameters.AddWithValue("@mtipi", araba.MotorTipi);
                komut.Parameters.AddWithValue("@mguc", araba.MaxGuc);
                komut.Parameters.AddWithValue("@mtork", araba.MaxTork);
                komut.Parameters.AddWithValue("@mrpm", araba.MaxRPM);
                komut.Parameters.AddWithValue("@yuze", araba.SifirdenYuze);
                komut.Parameters.AddWithValue("@agirlik", araba.Agirlik);
                komut.Parameters.AddWithValue("@mboyut", araba.MotorBoyutu);
                komut.Parameters.AddWithValue("@yakitk", araba.YakitKullanimi);
                komut.Parameters.AddWithValue("@valfs", araba.ValfSayisi);
                komut.Parameters.AddWithValue("@exaid", araba.EkzantrikID);
                komut.Parameters.AddWithValue("@enjid", araba.EnjeksiyonID);
                komut.Parameters.AddWithValue("@sanzid", araba.SanzimanID);
                komut.Parameters.AddWithValue("@vsayi", araba.VitesSayisi);
                komut.Parameters.AddWithValue("@cid", araba.CekisID);
                komut.Parameters.AddWithValue("@indid", araba.InduksiyonID);
                komut.Parameters.AddWithValue("@d", araba.Diger);
                baglanti.Open();
                komut.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public List<ElDurumu> ElGetir()
        {
            try
            {
                List<ElDurumu> eller = new List<ElDurumu>();
                ElDurumu el = new ElDurumu();
                el.ID = 0;
                el.El = "1.el";
                eller.Add(el);
                el.ID = 1;
                el.El = "2.el";
                eller.Add(el);
                return eller;
            }
            catch
            {
                return null;
            }
        }

        #endregion

        #region Parça Metotları

        public void ParcaSil(string db, int id)
        {
            try
            {
                komut.CommandText = "DELETE FROM @db WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", id);
                komut.Parameters.AddWithValue("@db", db);
                baglanti.Open();
                komut.ExecuteNonQuery();
            }
            finally
            {
                baglanti.Close();
            }
        }

        public bool ParcaKaydet(string db, int id, string isim)
        {
            try
            {
                komut.CommandText = "UPDATE @db SET @isimtipi=@isim WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", id);
                komut.Parameters.AddWithValue("@db", db);
                komut.Parameters.AddWithValue("@isim", isim);
                string isimtipi = "tip";
                if (db == "ArabaTip")
                {
                    isimtipi = "Tip";
                }
                else if (db == "ArabaYakit")
                {
                    isimtipi = "Yakit";
                }
                else if (db == "Sirketler")
                {
                    isimtipi = "SirketAdi";
                }
                komut.Parameters.AddWithValue("@isimtipi", isimtipi);
                baglanti.Open();
                komut.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                baglanti.Close();
            }
        }
        public List<ArabaTip> ArabaTipleriGetir()
        {
            try
            {
                List<ArabaTip> tipler = new List<ArabaTip>();
                komut.CommandText = "SELECT ID, Tip FROM ArabaTip";
                komut.Parameters.Clear();
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    ArabaTip tip = new ArabaTip();
                    tip.ID = reader.GetByte(0);
                    tip.Tip = reader.GetString(1);
                    tipler.Add(tip);
                }
                return tipler;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public List<ArabaYakit> ArabaYakitGetir()
        {
            try
            {
                List<ArabaYakit> yakitler = new List<ArabaYakit>();
                komut.CommandText = "SELECT ID, Yakit FROM ArabaYakit";
                komut.Parameters.Clear();
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    ArabaYakit yakit = new ArabaYakit();
                    yakit.ID = reader.GetByte(0);
                    yakit.Yakit = reader.GetString(1);
                    yakitler.Add(yakit);
                }
                return yakitler;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public List<ArabaEkzantrik> ArabaExaGetir()
        {
            try
            {
                List<ArabaEkzantrik> Exalar = new List<ArabaEkzantrik>();
                komut.CommandText = "SELECT ID, tip FROM ArabaEkzantrik";
                komut.Parameters.Clear();
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    ArabaEkzantrik exa = new ArabaEkzantrik();
                    exa.ID = reader.GetByte(0);
                    exa.tip = reader.GetString(1);
                    Exalar.Add(exa);
                }
                return Exalar;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public List<ArabaEnjeksiyon> ArabaEnjGetir()
        {
            try
            {
                List<ArabaEnjeksiyon> Enjler = new List<ArabaEnjeksiyon>();
                komut.CommandText = "SELECT ID, tip FROM ArabaEnjeksiyon";
                komut.Parameters.Clear();
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    ArabaEnjeksiyon enj = new ArabaEnjeksiyon();
                    enj.ID = reader.GetByte(0);
                    enj.tip = reader.GetString(1);
                    Enjler.Add(enj);
                }
                return Enjler;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public List<ArabaCekis> ArabaCekisGetir()
        {
            try
            {
                List<ArabaCekis> Cekisler = new List<ArabaCekis>();
                komut.CommandText = "SELECT ID, tip FROM ArabaCekis";
                komut.Parameters.Clear();
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    ArabaCekis cekis = new ArabaCekis();
                    cekis.ID = reader.GetByte(0);
                    cekis.tip = reader.GetString(1);
                    Cekisler.Add(cekis);
                }
                return Cekisler;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public List<ArabaInduksiyon> ArabaIndGetir()
        {
            try
            {
                List<ArabaInduksiyon> Indler = new List<ArabaInduksiyon>();
                komut.CommandText = "SELECT ID, tip FROM ArabaInduksiyon";
                komut.Parameters.Clear();
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    ArabaInduksiyon Ind = new ArabaInduksiyon();
                    Ind.ID = reader.GetByte(0);
                    Ind.tip = reader.GetString(1);
                    Indler.Add(Ind);
                }
                return Indler;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public List<ArabaSanziman> ArabaSanzGetir()
        {
            try
            {
                List<ArabaSanziman> Sanzlar = new List<ArabaSanziman>();
                komut.CommandText = "SELECT ID, tip FROM ArabaSanziman";
                komut.Parameters.Clear();
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    ArabaSanziman sanz = new ArabaSanziman();
                    sanz.ID = reader.GetByte(0);
                    sanz.tip = reader.GetString(1);
                    Sanzlar.Add(sanz);
                }
                return Sanzlar;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        #endregion

        #region Post metotları

        public List<Postlar> TumPostlariListeyeGetir()
        {
            List<Postlar> postlar = new List<Postlar>();
            try
            {
                komut.CommandText = "SELECT P.ID,P.Baslik,Y.KullaniciAdi,P.YuklemeTarihi,P.gizliMi,P.Durum FROM Postlar AS P JOIN Yoneticiler AS Y ON Y.ID = P.YazarID";
                komut.Parameters.Clear();
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    Postlar post = new Postlar();
                    post.ID = reader.GetInt32(0);
                    post.Baslik = reader.GetString(1);
                    post.YazarKAdi = reader.GetString(2);
                    post.YuklemeTarihi = reader.GetDateTime(3);
                    post.GizliMi = reader.GetBoolean(4);
                    post.Durum = reader.GetBoolean(5);
                    postlar.Add(post);
                }
                return postlar;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public List<Postlar> TumYazarliPostlariListeyeGetir(int YazarID)
        {
            List<Postlar> postlar = new List<Postlar>();
            try
            {
                komut.CommandText = "SELECT P.ID,P.Baslik,Y.KullaniciAdi,P.YuklemeTarihi,P.gizliMi,P.Durum FROM Postlar AS P JOIN Yoneticiler AS Y ON Y.ID = P.YazarID WHERE P.YazarID = @yid";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@yid", YazarID);
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    Postlar post = new Postlar();
                    post.ID = reader.GetInt32(0);
                    post.Baslik = reader.GetString(1);
                    post.YazarKAdi = reader.GetString(2);
                    post.YuklemeTarihi = reader.GetDateTime(3);
                    post.GizliMi = reader.GetBoolean(4);
                    post.Durum = reader.GetBoolean(5);
                    postlar.Add(post);
                }
                return postlar;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public List<Postlar> GecerliPostlariSayfayaGetir(short SirketID, int ArabaID)
        {
            List<Postlar> postlar = new List<Postlar>();
            try
            {
                komut.CommandText = "SELECT P.ID,P.Baslik,S.SirketAdi,A.Model,Y.KullaniciAdi,P.YuklemeTarihi,P.KapakFoto FROM Postlar AS P JOIN Arabalar AS A ON A.ID = P.ArabaID JOIN Yoneticiler AS Y ON Y.ID = P.YazarID JOIN Sirketler AS S ON S.ID = A.SirketID WHERE A.SirketID = @sid and A.ID = @aid and P.gizliMi = 0 and P.Durum = 1 ORDER BY P.YuklemeTarihi DESC";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@sid", SirketID);
                komut.Parameters.AddWithValue("@aid", ArabaID);
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    Postlar post = new Postlar();
                    post.ID = reader.GetInt32(0);
                    post.Baslik = reader.GetString(1);
                    post.ArabaModel = reader.GetString(2) + " " + reader.GetString(3);
                    post.YazarKAdi = reader.GetString(4);
                    post.YuklemeTarihi = reader.GetDateTime(5);
                    post.KapakFoto = reader.GetString(6);
                    postlar.Add(post);
                }
                return postlar;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public List<Postlar> GecerliPostlariSayfayaGetir(short SirketID)
        {
            List<Postlar> postlar = new List<Postlar>();
            try
            {
                komut.CommandText = "SELECT P.ID,P.Baslik,S.SirketAdi,A.Model,Y.KullaniciAdi,P.YuklemeTarihi,P.KapakFoto FROM Postlar AS P JOIN Arabalar AS A ON A.ID = P.ArabaID JOIN Yoneticiler AS Y ON Y.ID = P.YazarID JOIN Sirketler AS S ON S.ID = A.SirketID WHERE A.SirketID = @sid and P.gizliMi = 0 and P.Durum = 1 ORDER BY P.YuklemeTarihi DESC";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@sid", SirketID);
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    Postlar post = new Postlar();
                    post.ID = reader.GetInt32(0);
                    post.Baslik = reader.GetString(1);
                    post.ArabaModel = reader.GetString(2) + " " + reader.GetString(3);
                    post.YazarKAdi = reader.GetString(4);
                    post.YuklemeTarihi = reader.GetDateTime(5);
                    post.KapakFoto = reader.GetString(6);
                    postlar.Add(post);
                }
                return postlar;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public List<Postlar> GecerliPostlariSayfayaGetir()
        {
            List<Postlar> postlar = new List<Postlar>();
            try
            {
                komut.CommandText = "SELECT P.ID,P.Baslik,S.SirketAdi,A.Model,Y.KullaniciAdi,P.YuklemeTarihi,P.KapakFoto FROM Postlar AS P JOIN Arabalar AS A ON A.ID = P.ArabaID JOIN Yoneticiler AS Y ON Y.ID = P.YazarID JOIN Sirketler AS S ON S.ID = A.SirketID WHERE P.gizliMi = 0 and P.Durum = 1 ORDER BY P.YuklemeTarihi DESC";
                komut.Parameters.Clear();
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    Postlar post = new Postlar();
                    post.ID = reader.GetInt32(0);
                    post.Baslik = reader.GetString(1);
                    post.ArabaModel = reader.GetString(2) + " " + reader.GetString(3);
                    post.YazarKAdi = reader.GetString(4);
                    post.YuklemeTarihi = reader.GetDateTime(5);
                    post.KapakFoto = reader.GetString(6);
                    postlar.Add(post);
                }
                return postlar;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public Postlar PostGetir(int id)
        {
            try
            {
                Postlar post = new Postlar();
                komut.CommandText = "SELECT P.ID,Y.KullaniciAdi,P.ArabaID,P.Baslik,P.Aciklama,P.AlinanFiyat,P.AlinanYil,P.ElDurumu,P.YuklemeTarihi, P.gizliMi,P.Durum,P.KapakFoto FROM Postlar AS P JOIN Yoneticiler AS Y ON Y.ID = P.YazarID WHERE P.ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", id);
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    post.ID = reader.GetInt32(0);
                    post.YazarKAdi = reader.GetString(1);
                    post.ArabaID = reader.GetInt32(2);
                    post.Baslik = reader.GetString(3);
                    post.Aciklama = reader.GetString(4);
                    post.AlinanFiyat = reader.GetInt32(5);
                    post.AlinanYil = reader.GetInt16(6);
                    post.ElDurumu = reader.GetBoolean(7);
                    post.YuklemeTarihi = reader.GetDateTime(8);
                    post.GizliMi = reader.GetBoolean(9);
                    post.Durum = reader.GetBoolean(10);
                    post.KapakFoto = reader.GetString(11);
                }
                return post;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public bool PostEkle(Postlar post)
        {
            try
            {
                komut.CommandText = "INSERT INTO Postlar(YazarID,ArabaID,Aciklama,Baslik,AlinanFiyat,AlinanYil,ElDurumu,YuklemeTarihi,gizliMi,durum,KapakFoto) VALUES(@yid,@aid,@a,@b,@fiyat,@yil,@el,@tarih,@gizli,@d,@foto)";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@yid", post.YazarID);
                komut.Parameters.AddWithValue("@aid", post.ArabaID);
                komut.Parameters.AddWithValue("@a", post.Aciklama);
                komut.Parameters.AddWithValue("@b", post.Baslik);
                komut.Parameters.AddWithValue("@fiyat", post.AlinanFiyat);
                komut.Parameters.AddWithValue("@yil", post.AlinanYil);
                komut.Parameters.AddWithValue("@el", post.ElDurumu);
                komut.Parameters.AddWithValue("@tarih", post.YuklemeTarihi);
                komut.Parameters.AddWithValue("@gizli", post.GizliMi);
                komut.Parameters.AddWithValue("@d", post.Durum);
                komut.Parameters.AddWithValue("@foto", post.KapakFoto);
                baglanti.Open();
                komut.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public void PostSil(int id)
        {
            try
            {
                komut.CommandText = "DELETE FROM Postlar WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", id);
                baglanti.Open();
                komut.ExecuteNonQuery();
            }
            finally
            {
                baglanti.Close();
            }
        }

        public void PostDurumDegistir(int id)
        {
            try
            {
                komut.CommandText = "SELECT Durum FROM Postlar WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", id);
                baglanti.Open();
                bool durum = Convert.ToBoolean(komut.ExecuteScalar());
                komut.CommandText = "UPDATE Postlar SET durum=@d WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", id);
                komut.Parameters.AddWithValue("@d", !durum);
                komut.ExecuteNonQuery();
            }
            finally
            {
                baglanti.Close();
            }
        }

        public void PostGizle(int id)
        {
            try
            {
                komut.CommandText = "SELECT gizliMi FROM Postlar WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", id);
                baglanti.Open();
                bool gizli = Convert.ToBoolean(komut.ExecuteScalar());
                komut.CommandText = "UPDATE Postlar SET gizliMi=@g WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", id);
                komut.Parameters.AddWithValue("@g", !gizli);
                komut.ExecuteNonQuery();
            }
            finally
            {
                baglanti.Close();
            }
        }

        public bool PostDuzenle(Postlar post)
        {
            try
            {
                komut.CommandText = "UPDATE Postlar SET ArabaID=@aid,Aciklama=@a,Baslik=@b,AlinanFiyat=@fiyat,AlinanYil=@yil,ElDurumu=@el,gizliMi=@g, KapakFoto=@kf WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", post.ID);
                komut.Parameters.AddWithValue("@aid", post.ArabaID);
                komut.Parameters.AddWithValue("@a", post.Aciklama);
                komut.Parameters.AddWithValue("@b", post.Baslik);
                komut.Parameters.AddWithValue("@fiyat", post.AlinanFiyat);
                komut.Parameters.AddWithValue("@yil", post.AlinanYil);
                komut.Parameters.AddWithValue("@el", post.ElDurumu);
                komut.Parameters.AddWithValue("@g", post.GizliMi);
                komut.Parameters.AddWithValue("@kf", post.KapakFoto);
                baglanti.Open();
                komut.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                baglanti.Close();
            }
        }

        #endregion

        #region Yonetici Metotları

        public Yonetici YoneticiGiris(string kadi, string sifre)
        {
            try
            {
                Yonetici yon = new Yonetici();
                komut.CommandText = "Select ID,TurID,Isim,Soyisim,KullaniciAdi,Email,Sifre,Durum,OlusturmaTarihi FROM Yoneticiler WHERE KullaniciAdi=@kadi and Sifre=@s";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@kadi", kadi);
                komut.Parameters.AddWithValue("@s", sifre);
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    yon.ID = reader.GetInt32(0);
                    yon.TurID = reader.GetByte(1);
                    yon.Isim = reader.GetString(2);
                    yon.Soyisim = reader.GetString(3);
                    yon.KullaniciAdi = reader.GetString(4);
                    yon.Email = reader.GetString(5);
                    yon.Sifre = reader.GetString(6);
                    yon.Durum = reader.GetBoolean(7);
                    yon.OlusturmaTarihi = reader.GetDateTime(8);
                }
                return yon;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public string YoneticiTurGetir(int id)
        {
            try
            {
                komut.CommandText = "SELECT T.Rol FROM Turler AS T JOIN Yoneticiler AS Y ON Y.TurID = T.ID WHERE Y.ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", id);
                baglanti.Open();
                return Convert.ToString(komut.ExecuteScalar());
            }
            catch
            {
                return "";
            }
            finally
            {
                baglanti.Close();
            }
        }

        public bool YoneticiEkle(Yonetici yon)
        {
            try
            {
                komut.CommandText = "INSERT INTO Yoneticiler(TurID,Isim,Soyisim,KullaniciAdi,Email,Sifre,Durum,OlusturmaTarihi) VALUES(@tid,@isim,@soy,@kadi,@email,@sifre,@durum,@tarih)";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@tid", yon.TurID);
                komut.Parameters.AddWithValue("@isim", yon.Isim);
                komut.Parameters.AddWithValue("@soy", yon.Soyisim);
                komut.Parameters.AddWithValue("@kadi", yon.KullaniciAdi);
                komut.Parameters.AddWithValue("@email", yon.Email);
                komut.Parameters.AddWithValue("@sifre", yon.Sifre);
                komut.Parameters.AddWithValue("@durum", yon.Durum);
                komut.Parameters.AddWithValue("@tarih", yon.OlusturmaTarihi);
                baglanti.Open();
                komut.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                baglanti.Close();
            }
        }
        public bool YoneticiHesapDuzenle(Yonetici yon)
        {
            try
            {
                komut.CommandText = "UPDATE Yoneticiler SET Isim=@i,Soyisim=@soy,KullaniciAdi=@kadi,Sifre=@s,Email=@e WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", yon.ID);
                komut.Parameters.AddWithValue("@i", yon.Isim);
                komut.Parameters.AddWithValue("@soy", yon.Soyisim);
                komut.Parameters.AddWithValue("@kadi", yon.KullaniciAdi);
                komut.Parameters.AddWithValue("@s", yon.Sifre);
                komut.Parameters.AddWithValue("@e", yon.Email);
                baglanti.Open();
                komut.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                baglanti.Close();
            }
        }
        public bool? YoneticiKarsilastir(int postid, int yonID)
        {
            try
            {
                komut.CommandText = "SELECT YazarID FROM Postlar WHERE ID=@postid";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@postid", postid);
                baglanti.Open();
                if (Convert.ToInt32(komut.ExecuteScalar()) == yonID)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public bool? YoneticiKAdiMusaitMi(string isim)
        {
            try
            {
                List<string> Yoneticiler = new List<string>();
                komut.CommandText = "SELECT KullaniciAdi FROM Yoneticiler";
                komut.Parameters.Clear();
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    string ad = reader.GetString(0);
                    Yoneticiler.Add(ad);
                }
                for (int i = 0; i < Yoneticiler.Count; i++)
                {
                    string str = Yoneticiler[i];
                    if (str == isim)
                    {
                        return false;
                    }
                }
                return true;

            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }
        public List<Yonetici> YoneticiGetir(string isim)
        {
            try
            {
                List<Yonetici> Yoneticiler = new List<Yonetici>();
                komut.CommandText = "SELECT Y.ID,T.Rol,Y.Isim,Y.Soyisim,Y.KullaniciAdi,Y.Email,Y.Durum,Y.OlusturmaTarihi FROM Yoneticiler AS Y JOIN Turler AS T ON T.ID = Y.TurID";
                komut.Parameters.Clear();
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    Yonetici yonetici = new Yonetici();
                    yonetici.ID = reader.GetInt32(0);
                    yonetici.TurIsim = reader.GetString(1);
                    yonetici.Isim = reader.GetString(2);
                    yonetici.Soyisim = reader.GetString(3);
                    yonetici.KullaniciAdi = reader.GetString(4);
                    yonetici.Email = reader.GetString(5);
                    yonetici.Durum = reader.GetBoolean(6);
                    yonetici.OlusturmaTarihi = reader.GetDateTime(7);
                    Yoneticiler.Add(yonetici);
                }
                List<Yonetici> YeniYoneticiler = new List<Yonetici>();
                for (int i = 0; i < Yoneticiler.Count; i++)
                {
                    Yonetici yon = Yoneticiler[i];
                    if (Islem.dizidekelimevarmi(yon.KullaniciAdi.ToLower(), isim.ToLower()))
                    {
                        YeniYoneticiler.Add(yon);
                    }
                }
                return YeniYoneticiler;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public void YoneticiDurumDegistir(int id)
        {
            try
            {
                komut.CommandText = "SELECT Durum FROM Yoneticiler WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", id);
                baglanti.Open();
                bool durum = Convert.ToBoolean(komut.ExecuteScalar());
                komut.CommandText = "UPDATE Yoneticiler SET durum=@d WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", id);
                komut.Parameters.AddWithValue("@d", !durum);
                komut.ExecuteNonQuery();
            }
            finally
            {
                baglanti.Close();
            }
        }

        public List<Turler> RolGetir()
        {
            try
            {
                List<Turler> turler = new List<Turler>();
                komut.CommandText = "SELECT ID, Rol FROM Turler";
                komut.Parameters.Clear();
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    Turler tur = new Turler();
                    tur.ID = reader.GetByte(0);
                    tur.Rol = reader.GetString(1);
                    turler.Add(tur);
                }
                return turler;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        #endregion

        #region Üye Metotları

        public Uyeler UyeGiris(string kadi, string sifre)
        {
            try
            {
                Uyeler u = new Uyeler();
                komut.CommandText = "Select ID,KullaniciAdi,Email,Sifre,Durum,UyelikTarihi FROM Uyeler WHERE KullaniciAdi=@kadi and Sifre=@s";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@kadi", kadi);
                komut.Parameters.AddWithValue("@s", sifre);
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    u.ID = reader.GetInt32(0);
                    u.KullaniciAdi = reader.GetString(1);
                    u.Email = reader.GetString(2);
                    u.Sifre = reader.GetString(3);
                    u.Durum = reader.GetBoolean(4);
                    u.UyelikTarihi = reader.GetDateTime(5);
                }
                return u;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }
        public bool? UyeKAdiMusaitMi(string isim)
        {
            try
            {
                List<string> Uyeler = new List<string>();
                komut.CommandText = "SELECT KullaniciAdi FROM Uyeler";
                komut.Parameters.Clear();
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    string str = reader.GetString(0);
                    Uyeler.Add(str);
                }
                for (int i = 0; i < Uyeler.Count; i++)
                {
                    string str = Uyeler[i];
                    if (str == isim)
                    {
                        return false;
                    }
                }
                return true;

            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }
        public void UyeSil(int id)
        {
            try
            {
                komut.CommandText = "DELETE FROM Uyeler WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", id);
                baglanti.Open();
                komut.ExecuteNonQuery();
            }
            finally
            {
                baglanti.Close();
            }
        }
        public List<Uyeler> UyeGetir(string isim)
        {
            try
            {
                List<Uyeler> Uyeler = new List<Uyeler>();
                komut.CommandText = "SELECT ID,KullaniciAdi,Email,Durum,UyelikTarihi FROM Uyeler";
                komut.Parameters.Clear();
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    Uyeler uye = new Uyeler();
                    uye.ID = reader.GetInt32(0);
                    uye.KullaniciAdi = reader.GetString(1);
                    uye.Email = reader.GetString(2);
                    uye.Durum = reader.GetBoolean(3);
                    uye.UyelikTarihi = reader.GetDateTime(4);
                    Uyeler.Add(uye);
                }
                List<Uyeler> YeniUyeler = new List<Uyeler>();
                for (int i = 0; i < Uyeler.Count; i++)
                {
                    Uyeler uye = Uyeler[i];
                    if (Islem.dizidekelimevarmi(uye.KullaniciAdi.ToLower(), isim.ToLower()))
                    {
                        YeniUyeler.Add(uye);
                    }
                }
                return YeniUyeler;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }
        public void UyeDurumDegistir(int id)
        {
            try
            {
                komut.CommandText = "SELECT Durum FROM Uyeler WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", id);
                baglanti.Open();
                bool durum = Convert.ToBoolean(komut.ExecuteScalar());
                komut.CommandText = "UPDATE Uyeler SET durum=@d WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", id);
                komut.Parameters.AddWithValue("@d", !durum);
                komut.ExecuteNonQuery();
            }
            finally
            {
                baglanti.Close();
            }
        }
        public bool UyeHesapAc(Uyeler u)
        {
            try
            {
                komut.CommandText = "Insert INTO Uyeler(KullaniciAdi,Email,Sifre,Durum,UyelikTarihi) VALUES(@kadi,@e,@s,@d,@ut)";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@kadi", u.KullaniciAdi);
                komut.Parameters.AddWithValue("@e", u.Email);
                komut.Parameters.AddWithValue("@s", u.Sifre);
                komut.Parameters.AddWithValue("@d", u.Durum);
                komut.Parameters.AddWithValue("@ut", u.UyelikTarihi);
                baglanti.Open();
                komut.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                baglanti.Close();
            }
        }

        #endregion

        #region Yorum metotları

        public void YorumEkle(Yorumlar y)
        {

            try
            {
                komut.CommandText = "INSERT INTO Yorumlar(UyeID,PostID,Icerik,Tarih,Durum) VALUES(@uid,@pid,@icerik,@t,@d)";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@icerik", y.Icerik);
                komut.Parameters.AddWithValue("@uid", y.UyeID);
                komut.Parameters.AddWithValue("@pid", y.PostID);
                komut.Parameters.AddWithValue("@t", y.Tarih);
                komut.Parameters.AddWithValue("@d", y.Durum);
                baglanti.Open();
                komut.ExecuteNonQuery();
            }
            finally
            {
                baglanti.Close();
            }

        }

        public List<Yorumlar> OnaylanmamisYorumlariGetir()
        {
            List<Yorumlar> Yorumlar = new List<Yorumlar>();
            try
            {
                komut.CommandText = "SELECT Y.ID,U.KullaniciAdi,P.Baslik,Y.Icerik,Y.Tarih,Y.Durum FROM Yorumlar AS Y JOIN Uyeler AS U ON U.ID = Y.UyeID JOIN Postlar AS P ON P.ID = Y.PostID WHERE Y.Durum = 0";
                komut.Parameters.Clear();
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    Yorumlar yorum = new Yorumlar();
                    yorum.ID = reader.GetInt32(0);
                    yorum.Uye = reader.GetString(1);
                    yorum.Post = reader.GetString(2);
                    yorum.Icerik = reader.GetString(3);
                    yorum.Tarih = reader.GetDateTime(4);
                    yorum.Durum = reader.GetBoolean(5);
                    Yorumlar.Add(yorum);
                }
                return Yorumlar;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        public void YorumDurumDegistir(int id)
        {
            try
            {
                komut.CommandText = "SELECT Durum FROM Yorumlar WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", id);
                baglanti.Open();
                bool durum = Convert.ToBoolean(komut.ExecuteScalar());
                komut.CommandText = "UPDATE Yorumlar SET durum=@d WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", id);
                komut.Parameters.AddWithValue("@d", !durum);
                komut.ExecuteNonQuery();
            }
            finally
            {
                baglanti.Close();
            }
        }

        public void YorumSil(int id)
        {
            try
            {
                komut.CommandText = "DELETE FROM Yorumlar WHERE ID=@id";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@id", id);
                baglanti.Open();
                komut.ExecuteNonQuery();
            }
            finally
            {
                baglanti.Close();
            }
        }

        public List<Yorumlar> PostaYorumGetir(int PostID)
        {
            List<Yorumlar> Yorumlar = new List<Yorumlar>();
            try
            {
                komut.CommandText = "SELECT Y.ID,U.KullaniciAdi,Y.Icerik,Y.Tarih,Y.Durum FROM Yorumlar AS Y JOIN Uyeler AS U ON U.ID = Y.UyeID WHERE Y.Durum = 1 and Y.PostID = @pid";
                komut.Parameters.Clear();
                komut.Parameters.AddWithValue("@pid", PostID);
                baglanti.Open();
                SqlDataReader reader = komut.ExecuteReader();
                while (reader.Read())
                {
                    Yorumlar yorum = new Yorumlar();
                    yorum.ID = reader.GetInt32(0);
                    yorum.Uye = reader.GetString(1);
                    yorum.Icerik = reader.GetString(2);
                    yorum.Tarih = reader.GetDateTime(3);
                    yorum.Durum = reader.GetBoolean(4);
                    Yorumlar.Add(yorum);
                }
                return Yorumlar;
            }
            catch
            {
                return null;
            }
            finally
            {
                baglanti.Close();
            }
        }

        #endregion

        #region misc metotlar

        public string KarakterCevir(string str)
        {
            string newstr = "";
            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] == '.')
                {
                    newstr += ",";
                }
                else
                {
                    newstr += str[i];
                }
            }
            return newstr;
        }

        public short NullIseEksiInt16(string str)
        {
            return string.IsNullOrEmpty(str) ? Convert.ToInt16(-1) : Convert.ToInt16(str);
        }

        public int NullIseEksiInt32(string str)
        {
            return string.IsNullOrEmpty(str) ? Convert.ToInt32(-1) : Convert.ToInt32(str);
        }
        public double NullIseEksiDouble(string str)
        {
            return string.IsNullOrEmpty(str) ? Convert.ToDouble(-1) : Convert.ToDouble(str);
        }
        public byte NullIseEksiByte(string str)
        {
            return string.IsNullOrEmpty(str) ? Convert.ToByte(-1) : Convert.ToByte(str);
        }

        public bool EmailMi(string str)
        {
            bool b = false;
            if (str.Length >= 5)
            {
                int adim = 0;
                for (int i = 0; i < str.Length; i++)
                {
                    if (str[i] == '.' && adim == 3)
                    {
                        adim++;
                    }
                    if (str[i] != '@' && adim == 2)
                    {
                        adim++;
                    }
                    if (str[i] == '@' && adim == 1)
                    {
                        adim++;
                    }
                    if (str[i] != '@' && adim == 0)
                    {
                        adim++;
                    }
                    if (adim == 4)
                    {
                        return true;
                    }
                }
            }
            return b;
        }
        #endregion

        #region sayi metotları

        public int ToplamPostSayisi()
        {
            try
            {
                komut.CommandText = "SELECT count(*) FROM Postlar";
                komut.Parameters.Clear();
                baglanti.Open();
                return Convert.ToInt32(komut.ExecuteScalar());
            }
            catch
            {
                return 0;
            }
            finally
            {
                baglanti.Close();
            }
        }
        public int ToplamKullaniciSayisi()
        {
            try
            {
                komut.CommandText = "SELECT count(*) FROM Uyeler";
                komut.Parameters.Clear();
                baglanti.Open();
                return Convert.ToInt32(komut.ExecuteScalar());
            }
            catch
            {
                return 0;
            }
            finally
            {
                baglanti.Close();
            }
        }
        public int ToplamYoneticiSayisi()
        {
            try
            {
                komut.CommandText = "SELECT count(*) FROM Postlar";
                komut.Parameters.Clear();
                baglanti.Open();
                return Convert.ToInt32(komut.ExecuteScalar());
            }
            catch
            {
                return 0;
            }
            finally
            {
                baglanti.Close();
            }
        }
        public int ToplamYorumSayisi()
        {
            try
            {
                komut.CommandText = "SELECT count(*) FROM Yorumlar";
                komut.Parameters.Clear();
                baglanti.Open();
                return Convert.ToInt32(komut.ExecuteScalar());
            }
            catch
            {
                return 0;
            }
            finally
            {
                baglanti.Close();
            }
        }
        #endregion
    }
}
