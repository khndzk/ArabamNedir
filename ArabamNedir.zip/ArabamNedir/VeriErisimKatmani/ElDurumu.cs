﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VeriErisimKatmani
{
    public class ElDurumu
    {
        public int ID { get; set; }

        public string El { get; set; }
    }
}
