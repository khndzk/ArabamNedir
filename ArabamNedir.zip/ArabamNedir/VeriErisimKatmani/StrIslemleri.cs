﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VeriErisimKatmani
{
    public class StrIslemleri
    {
        public bool dizidekelimevarmi(string metin, string kelime)
        {
            #region çözüm
            for (int i = 0; i < metin.Length; i++)
            {
                bool varmi = true;
                for (int j = 0; j < kelime.Length; j++)
                {
                    if (metin[i + j] != kelime[j])
                    {
                        varmi = false;
                        break;
                    }
                }
                if (varmi == true)
                {
                    return true;
                }
            }
            return false;
            #endregion
        }
    }
}
