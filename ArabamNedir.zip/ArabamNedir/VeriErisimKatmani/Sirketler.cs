﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VeriErisimKatmani
{
    public class Sirketler
    {
        public int ID { get; set; }

        public string SirketAdi { get; set; }

    }
}
