﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VeriErisimKatmani
{
    public class ArabaSanziman
    {
        public byte ID { get; set; }
        public string tip { get; set; }
    }
}
