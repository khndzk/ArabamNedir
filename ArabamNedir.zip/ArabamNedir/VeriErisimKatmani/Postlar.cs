﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VeriErisimKatmani
{
    public class Postlar
    {
        public int ID { get; set; }
        public int YazarID { get; set; }

        public string YazarKAdi { get; set; }
        public int ArabaID { get; set; }
        public string ArabaModel { get; set; }
        public string Aciklama { get; set; }
        public string Baslik { get; set; }
        public int AlinanFiyat { get; set; }
        public short AlinanYil { get; set; }
        public bool ElDurumu { get; set; }
        public DateTime YuklemeTarihi { get; set; }
        public bool Durum { get; set; }
        public bool GizliMi { get; set; }
        public string KapakFoto { get; set; }
    }
}
