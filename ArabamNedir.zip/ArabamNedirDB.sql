Create Database ArabamNedirDB
Go
Use ArabamNedirDB
Go
Create Table Uyeler
(
ID int Identity(1,1),
KullaniciAdi Nvarchar(50),
Email Nvarchar(200),
Sifre Nvarchar(50),
Durum bit,
UyelikTarihi DateTime,
Constraint Uyeler_pk primary key(ID),
)
Go
Create Table Turler
(
ID tinyint Identity(1,1),
Rol Nvarchar(9),
Constraint Turler_pk primary key(ID),
)
Go
Create Table ArabaTip
(
ID tinyint Identity(1,1),
Tip Nvarchar(13),
Constraint ArabaTip_pk Primary Key(ID),
)
Create Table ArabaYakit
(
ID tinyint Identity(1,1),
Yakit Nvarchar(12),
Constraint ArabaYakit_pk primary key(ID),
)
Create Table Sirketler
(
ID smallint Identity(1,1),
SirketAdi Nvarchar(50),
Constraint Sirketler_pk primary key(ID),
)
Go
Create Table ArabaEkzantrik
(
ID tinyint Identity(1,1),
tip Nvarchar(5),
Constraint ArabaKamTipi_pk primary key(ID),
)
Go
Create Table ArabaEnjeksiyon
(
ID tinyint Identity(1,1),
tip Nvarchar(15),
Constraint ArabaEnjeksiyon_pk primary key(ID),
)
Go
Create Table ArabaSanziman
(
ID tinyint Identity(1,1),
tip Nvarchar(10),
Constraint ArabaSanziman_pk primary key(ID),
)
Go
Create Table ArabaCekis
(
ID tinyint Identity(1,1),
tip Nvarchar(3),
Constraint ArabaCekisTuru_pk primary key(ID),
)
Create Table ArabaInduksiyon
(
ID tinyint Identity(1,1),
tip Nvarchar(20),
Constraint ArabaInduksiyon_pk primary key(ID),
)
GO

Create Table Arabalar
(
ID int Identity(1,1),
TipID tinyint,
YakitID tinyint,
SirketID smallint,
Model Nvarchar(50),
CikisYili smallint,
MotorTipi nvarchar(4),
MaxGuc smallint,
MaxTork smallint,
MaxRPM smallint,
SifirdanYuze decimal(4,2),
Agirlik smallint,
MotorBoyutu decimal(6,3),
YakitKullanimi decimal(6,3),
ValfSayisi tinyint,
EkzantrikID tinyint,
EnjeksiyonID tinyint,
SanzimanID tinyint,
VitesSayisi tinyint,
CekisID tinyint,
InduksiyonID tinyint,
Diger Nvarchar(200),
Constraint Arabalar_pk primary key(ID),
Constraint ArabalarTip_fk foreign key (TipID) References ArabaTip(ID),
Constraint ArabalarYakit_fk foreign key (YakitID) References ArabaYakit(ID),
Constraint ArabalarSirket_fk foreign key (SirketID) References Sirketler(ID),
Constraint ArabalarExa_fk foreign key (EkzantrikID) References ArabaEkzantrik(ID),
Constraint ArabalarEnj_fk foreign key (EnjeksiyonID) References ArabaEnjeksiyon(ID),
Constraint ArabalarSanz_fk foreign key (SanzimanID) References ArabaSanziman(ID),
Constraint ArabalarCekis_fk foreign key (CekisID) References ArabaCekis(ID),
Constraint ArabalarInd_fk foreign key (InduksiyonID) References ArabaInduksiyon(ID),
)
GO
Create Table Yoneticiler
(
ID int Identity(1,1),
TurID tinyint,
Isim Nvarchar(75),
Soyisim Nvarchar(75),
KullaniciAdi Nvarchar(50),
Email Nvarchar(200),
Sifre Nvarchar(50),
Durum bit,
OlusturmaTarihi DateTime,
Constraint Yoneticiler_pk primary key(ID),
Constraint YoneticiTur_fk foreign key (TurID) References Turler(ID),
)
GO
Create Table Postlar
(
ID int Identity(1,1),
YazarID int,
ArabaID int,
Aciklama Nvarchar(4000),
Baslik Nvarchar(150),
AlinanFiyat int,
AlinanYil smallint,
ElDurumu bit,
YuklemeTarihi DateTime,
gizliMi bit,
durum bit,
KapakFoto Nvarchar(120),
Constraint Postlar_pk Primary key(ID),
Constraint PostlarYonetici_fk Foreign key(YazarID) References Yoneticiler(ID),
Constraint PostlarAraba_fk Foreign key(ArabaID) References Arabalar(ID),
)
GO
Create Table Yorumlar
(
ID int Identity(1,1),
UyeID int,
PostID int,
Icerik Nvarchar(500),
Tarih DateTime,
Durum bit,
Constraint Yorumlar_pk Primary key(ID),
Constraint YorumlarUye_fk Foreign key(UyeID) References Uyeler(ID),
Constraint YorumlarPost_fk Foreign key(PostID) References Postlar(ID),
)
GO
INSERT INTO Turler(Rol) Values('Admin')
INSERT INTO Turler(Rol) Values('Moderat�r')
INSERT INTO Turler(Rol) Values('Yazar')
GO
INSERT INTO ArabaTip(Tip) Values('Elektrik')
INSERT INTO ArabaTip(Tip) Values('Hibrit')
INSERT INTO ArabaTip(Tip) Values('��ten Yanmal�')
INSERT INTO ArabaYakit(Yakit) Values('Benzin')
INSERT INTO ArabaYakit(Yakit) Values('Dizel')
INSERT INTO ArabaYakit(Yakit) Values('Hidrojen')
INSERT INTO ArabaYakit(Yakit) Values('Elektrik')
INSERT INTO ArabaYakit(Yakit) Values('Di�er')
INSERT INTO Sirketler(SirketAdi) Values('BMW')
INSERT INTO ArabaCekis(tip) Values('FWD')
INSERT INTO ArabaCekis(tip) Values('AWD')
INSERT INTO ArabaCekis(tip) Values('4X4')
INSERT INTO ArabaCekis(tip) Values('RWD')
INSERT INTO ArabaCekis(tip) Values('4WD')
INSERT INTO ArabaEkzantrik(tip) Values('OHV')
INSERT INTO ArabaEkzantrik(tip) Values('DAOHC')
INSERT INTO ArabaEkzantrik(tip) Values('SOHC')
INSERT INTO ArabaEkzantrik(tip) Values('DOHC')
INSERT INTO ArabaEkzantrik(tip) Values('yok')
INSERT INTO ArabaEnjeksiyon(tip) Values('Direkt Enj.')
INSERT INTO ArabaEnjeksiyon(tip) Values('�oklu EFI')
INSERT INTO ArabaEnjeksiyon(tip) Values('Tekli EFI')
INSERT INTO ArabaEnjeksiyon(tip) Values('Mekanik Enj.')
INSERT INTO ArabaEnjeksiyon(tip) Values('Karb�rat�r')
INSERT INTO ArabaEnjeksiyon(tip) Values('yok')
INSERT INTO ArabaInduksiyon(tip) Values('Do�al Emi�li')
INSERT INTO ArabaInduksiyon(tip) Values('Turbo')
INSERT INTO ArabaInduksiyon(tip) Values('S�per�arj Turbo')
INSERT INTO ArabaInduksiyon(tip) Values('yok')
INSERT INTO ArabaSanziman(tip) Values('Otomatik')
INSERT INTO ArabaSanziman(tip) Values('Manuel')
INSERT INTO ArabaSanziman(tip) Values('Yar� Oto')
INSERT INTO ArabaSanziman(tip) Values('S�ral�')
INSERT INTO ArabaSanziman(tip) Values('DCT')
INSERT INTO ArabaSanziman(tip) Values('CVT')
INSERT INTO Yoneticiler(TurID,Isim,Soyisim,KullaniciAdi,Email,Sifre,Durum,OlusturmaTarihi) VALUES(1,'','','�rnekY�netici','OrnekYonetici@hotmail.com','1234',1,2024/04/30)